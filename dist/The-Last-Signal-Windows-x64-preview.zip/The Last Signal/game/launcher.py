"""Start the packaged game with saves outside the installation directory."""
import argparse
import os
from pathlib import Path
import secrets
import threading
import webbrowser

from backend.server import GameServer

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-open", action="store_true")
    args = parser.parse_args()
    if os.name == "nt":
        data = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "The Last Signal"
    else:
        data = Path.home() / "Library" / "Application Support" / "The Last Signal"
    # Use a different profile for automated smoke checks.
    if os.environ.get("TLS_DATA_DIR"):
        data = Path(os.environ["TLS_DATA_DIR"])
    data.mkdir(parents=True, exist_ok=True)
    key = data / "game.secret"
    try:
        with key.open("xb") as file:
            file.write(secrets.token_bytes(32))
    except FileExistsError:
        pass
    with GameServer(("127.0.0.1", 0), data / "game.sqlite3", key.read_bytes()) as server:
        url = f"http://127.0.0.1:{server.server_port}/"
        (data / "last-url.txt").write_text(url)
        if not args.no_open:
            threading.Timer(.25, webbrowser.open, args=(url,)).start()
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass

if __name__ == "__main__":
    main()
